import os
import requests
import pandas as pd
import joblib
from datetime import datetime
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago
from sklearn.linear_model import LinearRegression

default_args = {
    'owner': 'airflow',
    'start_date': days_ago(1),
}

dag = DAG(
    dag_id="real_umbrella_prague",
    default_args=default_args,
    description="Fetch Prague weather, clean, add delta, create changes table, train ML, deploy.",
    schedule_interval="@daily",
    catchup=False
)

def fetch_weather_forecast():
    # Открытый API Open-Meteo (Прага, прогноз на 3 дня, средняя температура)
    url = (
        "https://api.open-meteo.com/v1/forecast?"
        "latitude=50.0880&longitude=14.4208"
        "&daily=temperature_2m_mean"
        "&timezone=Europe%2FPrague"
        "&forecast_days=3"
    )
    
    response = requests.get(url)
    data = response.json()
    
    # Извлекаем списки дат и температур из JSON
    dates = data['daily']['time']
    temperatures = data['daily']['temperature_2m_mean']
    
    # Создаем DataFrame (имена колонок такие же, чтобы остальные функции работали)
    df = pd.DataFrame({
        'date': dates,
        'temperature': temperatures
    })
    
    data_dir = '/opt/airflow/data'
    os.makedirs(data_dir, exist_ok=True)
    df.to_csv(os.path.join(data_dir, 'weather_forecast.csv'), index=False)
    print("Weather forecast for Prague saved via Open-Meteo (3 days).")

def clean_weather_data():
    data_dir = '/opt/airflow/data'
    df = pd.read_csv(os.path.join(data_dir, 'weather_forecast.csv'))
    
    # Очистка
    df['temperature'] = df['temperature'].ffill()
    
    # Добавление столбца "дельта с предыдущим днем"
    df['delta_temp'] = df['temperature'].diff()
    
    # Заполняем первое значение дельты (NaN) нулем
    df['delta_temp'] = df['delta_temp'].fillna(0)
    
    df.to_csv(os.path.join(data_dir, 'clean_weather.csv'), index=False)
    print("Cleaned weather data with 'delta_temp' saved.")

def fetch_sales_data():
    data_dir = '/opt/airflow/data'
    # Чтобы join сработал, берём даты из прогноза
    weather_df = pd.read_csv(os.path.join(data_dir, 'weather_forecast.csv'))
    dates = weather_df['date'].tolist()
    
    # Моковые данные продаж
    sales = [10, 15, 20][:len(dates)]  # 3 дня
    
    df = pd.DataFrame({'date': dates, 'sales': sales})
    df.to_csv(os.path.join(data_dir, 'sales_data.csv'), index=False)
    print("Sales data saved.")

def clean_sales_data():
    data_dir = '/opt/airflow/data'
    df = pd.read_csv(os.path.join(data_dir, 'sales_data.csv'))
    df['sales'] = df['sales'].ffill()
    df.to_csv(os.path.join(data_dir, 'clean_sales.csv'), index=False)
    print("Cleaned sales data saved.")

def join_datasets():
    data_dir = '/opt/airflow/data'
    weather_df = pd.read_csv(os.path.join(data_dir, 'clean_weather.csv'))
    sales_df = pd.read_csv(os.path.join(data_dir, 'clean_sales.csv'))
    
    # Объединение
    joined_df = pd.merge(weather_df, sales_df, on='date', how='inner')
    joined_df.to_csv(os.path.join(data_dir, 'joined_data.csv'), index=False)
    print("Joined dataset saved.")

def create_changes_table():
    data_dir = '/opt/airflow/data'
    df = pd.read_csv(os.path.join(data_dir, 'joined_data.csv'))
    
    # Создаем таблицу изменений
    changes_df = df[['date', 'temperature', 'delta_temp', 'sales']].copy()
    
    # Добавляем столбец с типом изменения температуры
    changes_df['temp_change_type'] = changes_df['delta_temp'].apply(
        lambda x: 'increase' if x > 0 else ('decrease' if x < 0 else 'no_change')
    )
    
    # Добавляем столбец с абсолютным значением изменения температуры
    changes_df['abs_delta_temp'] = changes_df['delta_temp'].abs()
    
    # Добавляем столбец с изменением продаж относительно предыдущего дня
    changes_df['sales_change'] = changes_df['sales'].diff().fillna(0)
    changes_df['sales_change_type'] = changes_df['sales_change'].apply(
        lambda x: 'increase' if x > 0 else ('decrease' if x < 0 else 'no_change')
    )
    
    # Сохраняем таблицу изменений
    changes_df.to_csv(os.path.join(data_dir, 'changes_table.csv'), index=False)
    print("Changes table created and saved.")
    
    # Выводим таблицу изменений для визуализации в логах
    print("\n=== TABLE OF CHANGES ===")
    print(changes_df.to_string(index=False))
    print("========================")

def train_ml_model():
    data_dir = '/opt/airflow/data'
    df = pd.read_csv(os.path.join(data_dir, 'joined_data.csv'))
    
    X = df[['temperature', 'delta_temp']]  # Используем оба признака
    y = df['sales']
    
    model = LinearRegression()
    model.fit(X, y)
    
    joblib.dump(model, os.path.join(data_dir, 'ml_model.pkl'))
    print("ML model trained and saved.")
    
    # Выводим коэффициенты модели
    print(f"Model coefficients: temperature={model.coef_[0]:.2f}, delta_temp={model.coef_[1]:.2f}")
    print(f"Model intercept: {model.intercept_:.2f}")

def deploy_ml_model():
    data_dir = '/opt/airflow/data'
    model = joblib.load(os.path.join(data_dir, 'ml_model.pkl'))
    
    # Загружаем таблицу изменений для демонстрации
    changes_df = pd.read_csv(os.path.join(data_dir, 'changes_table.csv'))
    
    print("Model deployed successfully:", model)
    print("\n=== MODEL PREDICTIONS BASED ON CHANGES TABLE ===")
    
    # Делаем предсказания на основе данных из таблицы изменений
    X_new = changes_df[['temperature', 'delta_temp']]
    predictions = model.predict(X_new)
    
    for i, row in changes_df.iterrows():
        print(f"Date: {row['date']}, Temperature: {row['temperature']}°C, "
              f"Delta: {row['delta_temp']}°C, Predicted Sales: {predictions[i]:.2f}, "
              f"Actual Sales: {row['sales']}")

# Инициализация операторов
t1 = PythonOperator(task_id="fetch_weather_forecast", python_callable=fetch_weather_forecast, dag=dag)
t2 = PythonOperator(task_id="clean_weather_data", python_callable=clean_weather_data, dag=dag)
t3 = PythonOperator(task_id="fetch_sales_data", python_callable=fetch_sales_data, dag=dag)
t4 = PythonOperator(task_id="clean_sales_data", python_callable=clean_sales_data, dag=dag)
t5 = PythonOperator(task_id="join_datasets", python_callable=join_datasets, dag=dag)
t6 = PythonOperator(task_id="create_changes_table", python_callable=create_changes_table, dag=dag)
t7 = PythonOperator(task_id="train_ml_model", python_callable=train_ml_model, dag=dag)
t8 = PythonOperator(task_id="deploy_ml_model", python_callable=deploy_ml_model, dag=dag)

# Настройка зависимостей (граф)
t1 >> t2
t3 >> t4
[t2, t4] >> t5
t5 >> t6 >> t7 >> t8