# Проектный практикум по разработке ETL-решений: Лабораторная работа №5

## Постановка задачи (Вариант 20)
Разработать контейнеризированное ETL-решение на базе Apache Airflow для автоматизации пайплайна обработки данных со следующими требованиями:
- Получить прогноз погоды в **Москве на 7 дней** (используя внешний API).
- Обработать данные: добавить столбец **"день недели"**.
- Сгенерировать данные о продажах за эти же даты и объединить наборы данных.
- Обучить простейшую ML-модель (Линейная регрессия).
- Построить **график температуры по дням недели** (в качестве инструмента визуализации добавлен Streamlit).

## Архитектура проекта

```mermaid
graph TD
    subgraph External Sources
        API[WeatherAPI.com]
    end

    subgraph Docker Infrastructure
        PG[(PostgreSQL Airflow Metadata)]
        
        subgraph Airflow Components
            SCH[Scheduler]
            WEB[Webserver :8080]
            INIT[Init-container]
        end
        
        subgraph Visualization
            STR[Streamlit App :8501]
        end
        
        VOL[Shared Volume /opt/airflow/data]
    end

    subgraph User
        BROWSER((Browser))
    end

    API -->|JSON forecast| SCH
    SCH -->|Saves CSV| VOL
    SCH <-->|Reads/Writes State| PG
    WEB <-->|Reads State| PG
    STR -->|Reads CSV| VOL
    
    BROWSER -->|Monitors DAGs| WEB
    BROWSER -->|Views Dashboard| STR
```

## Технический стек
* **Оркестрация:** Apache Airflow 2.8.1
* **Контейнеризация:** Docker, Docker Compose
* **Язык программирования:** Python 3.11
* **Библиотеки (ETL & ML):** Pandas, Scikit-learn, Joblib, Requests
* **Визуализация:** Streamlit, Matplotlib
* **База данных:** PostgreSQL 12 (для метаданных Airflow)

## Описание DAG (`real_umbrella_containerized`)
Пайплайн состоит из следующих задач (Task):
1. **`fetch_weather_forecast`**: Обращается к WeatherAPI, получает прогноз для **Москвы** на 7 дней, сохраняет в `weather_forecast.csv`.
2. **`clean_weather_data`**: Заполняет пропуски, вычисляет и **добавляет столбец "день недели"** на русском языке, сохраняет в `clean_weather.csv`.
3. **`fetch_sales_data`**: Читает даты из прогноза погоды и генерирует данные о продажах на эти же даты (чтобы `join` отработал корректно), сохраняет в `sales_data.csv`.
4. **`clean_sales_data`**: Очищает данные продаж.
5. **`join_datasets`**: Объединяет погоду и продажи по дате (Inner Join).
6. **`train_ml_model`**: Обучает линейную регрессию предсказывать продажи по температуре.
7. **`deploy_ml_model`**: Имитирует деплой (загружает сохраненную `.pkl` модель).

---

## Исходный код

Перед началом создайте следующую структуру директорий:
```text
project/
├── dags/
│   └── real_umbrella.py
├── app/
│   └── app.py
├── data/
├── docker-compose.yml
└── Dockerfile
```

### 1. `Dockerfile`
Добавлен `streamlit` и `matplotlib` для графиков.
```dockerfile
FROM apache/airflow:slim-2.8.1-python3.11

USER airflow

# Устанавливаем необходимые Python-библиотеки
RUN pip install --no-cache-dir \
    pandas \
    scikit-learn \
    joblib \
    requests \
    azure-storage-blob==12.8.1 \
    psycopg2-binary \
    streamlit \
    matplotlib \
    "connexion[swagger-ui]"

USER root

# Создаём директории и назначаем владельца
RUN mkdir -p /opt/airflow/data /opt/airflow/logs /opt/airflow/app \
    && chown -R airflow: /opt/airflow/data /opt/airflow/logs /opt/airflow/app

USER airflow
```

### 2. `docker-compose.yml`
Добавлен сервис `streamlit` для визуализации графиков.
```yaml
x-environment: &airflow_environment
  - AIRFLOW__CORE__EXECUTOR=LocalExecutor
  - AIRFLOW__DATABASE__SQL_ALCHEMY_CONN=postgresql+psycopg2://airflow:airflow@postgres:5432/airflow
  - AIRFLOW__CORE__LOAD_DEFAULT_CONNECTIONS=False
  - AIRFLOW__CORE__LOAD_EXAMPLES=False
  - AIRFLOW__CORE__STORE_DAG_CODE=True
  - AIRFLOW__CORE__STORE_SERIALIZED_DAGS=True
  - AIRFLOW__WEBSERVER__EXPOSE_CONFIG=True
  - AIRFLOW__WEBSERVER__RBAC=False
  - AIRFLOW__WEBSERVER__SECRET_KEY=supersecretkey123
  - AIRFLOW__LOGGING__LOGGING_LEVEL=INFO
  - AIRFLOW__LOGGING__REMOTE_LOGGING=False
  - AIRFLOW__LOGGING__BASE_LOG_FOLDER=/opt/airflow/logs

x-airflow-image: &airflow_image custom-airflow:slim-2.8.1-python3.11

services:
  postgres:
    image: postgres:12-alpine
    environment:
      - POSTGRES_USER=airflow
      - POSTGRES_PASSWORD=airflow
      - POSTGRES_DB=airflow
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD", "pg_isready", "-U", "airflow"]
      interval: 10s
      timeout: 5s
      retries: 5

  init:
    image: *airflow_image
    depends_on:
      postgres:
        condition: service_healthy
    environment: *airflow_environment
    volumes:
      - ./dags:/opt/airflow/dags
      - ./data:/opt/airflow/data
      - logs:/opt/airflow/logs
    entrypoint: >
      bash -c "
      airflow db upgrade &&
      airflow users create --username admin --password admin --firstname Admin --lastname User --role Admin --email admin@example.org &&
      echo 'Airflow init completed.'"
    healthcheck:
      test: ["CMD", "airflow", "db", "check"]
      interval: 10s
      retries: 5
      start_period: 10s

  webserver:
    image: *airflow_image
    depends_on:
      init:
        condition: service_completed_successfully
    ports:
      - "8080:8080"
    restart: always
    environment: *airflow_environment
    volumes:
      - ./dags:/opt/airflow/dags
      - ./data:/opt/airflow/data
      - logs:/opt/airflow/logs
    command: webserver

  scheduler:
    image: *airflow_image
    depends_on:
      init:
        condition: service_completed_successfully
    restart: always
    environment: *airflow_environment
    volumes:
      - ./dags:/opt/airflow/dags
      - ./data:/opt/airflow/data
      - logs:/opt/airflow/logs
    command: scheduler

  streamlit:
    image: *airflow_image
    depends_on:
      init:
        condition: service_completed_successfully
    ports:
      - "8501:8501"
    restart: always
    volumes:
      - ./data:/opt/airflow/data
      - ./app:/opt/airflow/app
    command: bash -c "streamlit run /opt/airflow/app/app.py --server.port=8501 --server.address=0.0.0.0"

volumes:
  logs:
  postgres_data:
```

### 3. `dags/real_umbrella.py`
Скорректирован для Москвы, добавления дня недели и генерации корректных дат для join.
*Примечание: вставьте ваш реальный API-ключ от WeatherAPI.*

```python
import os
import requests
import pandas as pd
import joblib
from datetime import datetime
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.utils.dates import days_ago
from sklearn.linear_model import LinearRegression

default_args = {
    'owner': 'airflow',
    'start_date': days_ago(1),
}

dag = DAG(
    dag_id="real_umbrella_moscow",
    default_args=default_args,
    description="Fetch Moscow weather, clean, add weekday, train ML, deploy.",
    schedule_interval="@daily",
    catchup=False
)

def fetch_weather_forecast():
    # Открытый API Open-Meteo (Москва, прогноз на 7 дней, средняя температура)
    url = (
        "https://api.open-meteo.com/v1/forecast?"
        "latitude=55.75&longitude=37.62"
        "&daily=temperature_2m_mean"
        "&timezone=Europe%2FMoscow"
        "&forecast_days=7"
    )
    
    response = requests.get(url)
    data = response.json()
    
    # Извлекаем списки дат и температур из JSON
    dates = data['daily']['time']
    temperatures = data['daily']['temperature_2m_mean']
    
    # Создаем DataFrame (имена колонок такие же, чтобы остальные функции работали)
    df = pd.DataFrame({
        'date': dates,
        'temperature': temperatures
    })
    
    data_dir = '/opt/airflow/data'
    os.makedirs(data_dir, exist_ok=True)
    df.to_csv(os.path.join(data_dir, 'weather_forecast.csv'), index=False)
    print("Weather forecast for Moscow saved via Open-Meteo (No API Key).")

def clean_weather_data():
    data_dir = '/opt/airflow/data'
    df = pd.read_csv(os.path.join(data_dir, 'weather_forecast.csv'))
    
    # Очистка
    df['temperature'] = df['temperature'].ffill()
    
    # Добавление столбца "день недели"
    df['date'] = pd.to_datetime(df['date'])
    days_map = {
        0: 'Понедельник', 1: 'Вторник', 2: 'Среда', 
        3: 'Четверг', 4: 'Пятница', 5: 'Суббота', 6: 'Воскресенье'
    }
    df['день недели'] = df['date'].dt.weekday.map(days_map)
    
    df.to_csv(os.path.join(data_dir, 'clean_weather.csv'), index=False)
    print("Cleaned weather data with 'день недели' saved.")

def fetch_sales_data():
    data_dir = '/opt/airflow/data'
    # Чтобы join сработал, берём даты из прогноза
    weather_df = pd.read_csv(os.path.join(data_dir, 'weather_forecast.csv'))
    dates = weather_df['date'].tolist()
    
    # Моковые данные продаж
    sales = [10, 15, 20, 25, 30, 10, 5][:len(dates)]
    
    df = pd.DataFrame({'date': dates, 'sales': sales})
    df.to_csv(os.path.join(data_dir, 'sales_data.csv'), index=False)
    print("Sales data saved.")

def clean_sales_data():
    data_dir = '/opt/airflow/data'
    df = pd.read_csv(os.path.join(data_dir, 'sales_data.csv'))
    df['sales'] = df['sales'].ffill()
    df.to_csv(os.path.join(data_dir, 'clean_sales.csv'), index=False)
    print("Cleaned sales data saved.")

def join_datasets():
    data_dir = '/opt/airflow/data'
    weather_df = pd.read_csv(os.path.join(data_dir, 'clean_weather.csv'))
    sales_df = pd.read_csv(os.path.join(data_dir, 'clean_sales.csv'))
    
    # Объединение
    joined_df = pd.merge(weather_df, sales_df, on='date', how='inner')
    joined_df.to_csv(os.path.join(data_dir, 'joined_data.csv'), index=False)
    print("Joined dataset saved.")

def train_ml_model():
    data_dir = '/opt/airflow/data'
    df = pd.read_csv(os.path.join(data_dir, 'joined_data.csv'))
    
    X = df[['temperature']]
    y = df['sales']
    
    model = LinearRegression()
    model.fit(X, y)
    
    joblib.dump(model, os.path.join(data_dir, 'ml_model.pkl'))
    print("ML model trained and saved.")

def deploy_ml_model():
    data_dir = '/opt/airflow/data'
    model = joblib.load(os.path.join(data_dir, 'ml_model.pkl'))
    print("Model deployed successfully:", model)

# Инициализация операторов
t1 = PythonOperator(task_id="fetch_weather_forecast", python_callable=fetch_weather_forecast, dag=dag)
t2 = PythonOperator(task_id="clean_weather_data", python_callable=clean_weather_data, dag=dag)
t3 = PythonOperator(task_id="fetch_sales_data", python_callable=fetch_sales_data, dag=dag)
t4 = PythonOperator(task_id="clean_sales_data", python_callable=clean_sales_data, dag=dag)
t5 = PythonOperator(task_id="join_datasets", python_callable=join_datasets, dag=dag)
t6 = PythonOperator(task_id="train_ml_model", python_callable=train_ml_model, dag=dag)
t7 = PythonOperator(task_id="deploy_ml_model", python_callable=deploy_ml_model, dag=dag)

# Настройка зависимостей (граф)
t1 >> t2
t3 >> t4
[t2, t4] >> t5
t5 >> t6 >> t7
```

### 4. `app/app.py` (Streamlit Дашборд)
Скрипт строит график по сформированным данным.
```python
import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import os

st.set_page_config(page_title="Прогноз погоды Москва", layout="wide")
st.title("Анализ погоды в Москве на 7 дней (Вариант 20)")

data_path = '/opt/airflow/data/clean_weather.csv'

if os.path.exists(data_path):
    df = pd.read_csv(data_path)
    
    st.write("### Очищенные данные с добавленным столбцом 'день недели'")
    st.dataframe(df)

    st.write("### График: Температура по дням недели")
    
    fig, ax = plt.subplots(figsize=(10, 5))
    # Чтобы график не сортировался по алфавиту, используем исходный порядок из df
    ax.plot(df['день недели'], df['temperature'], marker='o', color='orange', linewidth=2)
    ax.set_xlabel('День недели')
    ax.set_ylabel('Температура (°C)')
    ax.grid(True, linestyle='--', alpha=0.7)
    
    st.pyplot(fig)
else:
    st.warning("Данные еще не сгенерированы. Пожалуйста, запустите DAG в Airflow.")
```

---

## Ход выполнения


В  `docker-compose.yml` папка `data` пробрасывается из локальной системы внутрь контейнера (bind mount):
`- ./data:/opt/airflow/data`

Когда Docker монтирует  локальную папку `./data` в контейнер, она **перезаписывает** те права доступа, которые мы указывали в `Dockerfile` (`chown -R airflow`). 
Локальная папка принадлежит  пользователю компьютера (или root), а Airflow внутри контейнера работает от ограниченного пользователя `airflow` (обычно с UID 50000). Из-за этого у Airflow нет прав создать файл в этой папке.


```bash
sudo chown -R 50000:0 ./data
sudo chown -R dev:dev /home/dev/Downloads/practice/business_case_umbrella_25
```
### Подготовка и сборка кастомного образа
Поскольку в проекте используются дополнительные библиотеки (Pandas, Scikit-learn, Streamlit и др.), перед запуском оркестратора необходимо собрать кастомный Docker-образ из `Dockerfile`. 
Откройте терминал в корневой папке проекта (где лежат `Dockerfile` и `docker-compose.yml`) и выполните:

```bash
docker build -t custom-airflow:slim-2.8.1-python3.11 .
```

### Запуск проекта
После того как образ успешно собран, запустите всю инфраструктуру (PostgreSQL, Airflow Init, Webserver, Scheduler и Streamlit) в фоновом режиме:
```bash
docker compose up -d
```

### Проверка запущенных контейнеров
Убедитесь, что инфраструктура поднялась без ошибок. Для вывода списка активных контейнеров и их статусов используйте команду:
```bash
docker ps
```
*(Вы должны увидеть контейнеры с именами, содержащими `postgres`, `webserver`, `scheduler`, `streamlit`. Контейнер `init` завершит работу после настройки БД).*

### Просмотр логов
Чтобы отследить процесс инициализации Airflow или диагностировать работу компонентов, посмотрите логи.
Для просмотра логов всех сервисов в реальном времени:
```bash
docker compose logs -f
```
Для просмотра логов конкретного сервиса (например, чтобы убедиться, что `init` создал пользователя):
```bash
docker compose logs init
```
*(Для выхода из режима потокового чтения логов нажмите `Ctrl+C`)*.

### Выполнение DAG и получение визуализации
1. **Запуск пайплайна (Airflow):** 
   * Перейдите в браузере по адресу [http://localhost:8080](http://localhost:8080).
   * Авторизуйтесь (логин: `admin`, пароль: `admin`).
   * Найдите ваш DAG в списке, снимите его с паузы (переключатель слева) и запустите вручную, нажав кнопку **Play (▶)** ➜ **Trigger DAG**.
   * Дождитесь успешного выполнения всех задач (статус поменяется на темно-зеленый "Success"). Данные скачаются, обработаются и сохранится модель.
2. **Просмотр визуализации (Streamlit):**
   * Перейдите по адресу [http://localhost:8501](http://localhost:8501).
   * На открывшемся дашборде вы увидите очищенную таблицу с добавленным столбцом "день недели" и требуемый график температуры по дням недели.

### Выключение проекта и полная очистка ресурсов
После успешного завершения работы необходимо остановить сервисы, удалить контейнеры, очистить сеть, тома данных (volumes) и собранные образы.

1. Остановка контейнеров, удаление связанной сети и томов:
```bash
docker compose down -v
```
2. Удаление кастомного Docker-образа Airflow:
```bash
docker rmi custom-airflow:slim-2.8.1-python3.11
```
3. *(Опционально)* Очистка системы от зависших ("dangling") сетей и слоёв кэша сборки:
```bash
docker network prune -f
docker image prune -f
```
4. Если необходимо удалить сгенерированные файлы данных из локальной папки:
```bash
rm -rf data/*
```
