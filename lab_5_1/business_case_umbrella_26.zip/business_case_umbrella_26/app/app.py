import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import os

st.set_page_config(page_title="Прогноз погоды Прага", layout="wide")
st.title("Анализ погоды в Праге на 3 дня (Вариант 13)")

# Загружаем таблицу изменений
changes_path = '/opt/airflow/data/changes_table.csv'
weather_path = '/opt/airflow/data/clean_weather.csv'

if os.path.exists(changes_path) and os.path.exists(weather_path):
    changes_df = pd.read_csv(changes_path)
    weather_df = pd.read_csv(weather_path)
    
    st.write("### Таблица изменений")
    st.write("Данные с изменениями температуры и продаж по дням")
    
    # Переименовываем колонки для удобства отображения
    display_df = changes_df.rename(columns={
        'date': 'Дата',
        'temperature': 'Температура (°C)',
        'delta_temp': 'Дельта температуры (°C)',
        'sales': 'Продажи',
        'temp_change_type': 'Изменение температуры',
        'abs_delta_temp': 'Абсолютное изменение температуры',
        'sales_change': 'Изменение продаж',
        'sales_change_type': 'Изменение продаж (тип)'
    })
    
    st.dataframe(display_df, use_container_width=True)
    
    st.write("### Графики: Температура и изменения")
    
    col1, col2 = st.columns(2)
    
    with col1:
        fig1, ax1 = plt.subplots(figsize=(8, 5))
        ax1.plot(weather_df['date'], weather_df['temperature'], marker='o', color='orange', linewidth=2)
        ax1.set_xlabel('Дата')
        ax1.set_ylabel('Температура (°C)')
        ax1.set_title('Изменение температуры по дням')
        ax1.grid(True, linestyle='--', alpha=0.7)
        plt.xticks(rotation=45)
        st.pyplot(fig1)
    
    with col2:
        fig2, ax2 = plt.subplots(figsize=(8, 5))
        colors = ['red' if x < 0 else 'green' if x > 0 else 'blue' for x in changes_df['delta_temp']]
        bars = ax2.bar(changes_df['date'], changes_df['delta_temp'], color=colors, alpha=0.7)
        ax2.set_xlabel('Дата')
        ax2.set_ylabel('Дельта температуры (°C)')
        ax2.set_title('Изменение температуры относительно предыдущего дня')
        ax2.axhline(y=0, color='black', linestyle='-', linewidth=0.5)
        ax2.grid(True, linestyle='--', alpha=0.3)
        plt.xticks(rotation=45)
        
        for bar, delta in zip(bars, changes_df['delta_temp']):
            height = bar.get_height()
            ax2.text(bar.get_x() + bar.get_width()/2., height,
                    f'{delta:.1f}°C', ha='center', va='bottom' if height > 0 else 'top')
        
        st.pyplot(fig2)
    
    st.write("### Статистика изменений")
    
    col3, col4, col5 = st.columns(3)
    with col3:
        st.metric("Максимальное повышение температуры", f"{changes_df['delta_temp'].max():.1f}°C")
    with col4:
        st.metric("Максимальное понижение температуры", f"{changes_df['delta_temp'].min():.1f}°C")
    with col5:
        st.metric("Среднее абсолютное изменение", f"{changes_df['delta_temp'].abs().mean():.1f}°C")
    
    # Дополнительная статистика по продажам
    st.write("### Статистика продаж")
    col6, col7, col8 = st.columns(3)
    with col6:
        st.metric("Максимальные продажи", f"{changes_df['sales'].max()}")
    with col7:
        st.metric("Минимальные продажи", f"{changes_df['sales'].min()}")
    with col8:
        st.metric("Средние продажи", f"{changes_df['sales'].mean():.1f}")
    
    # Информация о модели ML
    model_path = '/opt/airflow/data/ml_model.pkl'
    if os.path.exists(model_path):
        st.write("### Информация о ML модели")
        st.info("✅ Модель машинного обучения обучена и готова к использованию")
        
        # Показываем последние предсказания если есть
        if 'sales' in changes_df.columns and 'temperature' in changes_df.columns:
            st.write("**Последние данные для предсказания:**")
            last_row = changes_df.iloc[-1]
            st.write(f"- Дата: {last_row['date']}")
            st.write(f"- Температура: {last_row['temperature']}°C")
            st.write(f"- Дельта температуры: {last_row['delta_temp']}°C")
            st.write(f"- Фактические продажи: {last_row['sales']}")
    
else:
    st.warning("Данные еще не сгенерированы. Пожалуйста, запустите DAG в Airflow.")
    st.write("Ожидаемые файлы:")
    st.write("- /opt/airflow/data/changes_table.csv")
    st.write("- /opt/airflow/data/clean_weather.csv")